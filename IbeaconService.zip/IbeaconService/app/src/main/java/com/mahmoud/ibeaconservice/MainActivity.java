package com.mahmoud.ibeaconservice;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import com.estimote.sdk.SystemRequirementsChecker;


public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
                startService(new Intent(this, EstimoteService.class));

        EstimoteManager.Create((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE), getApplicationContext(), new Intent(MainActivity.this, MainActivity.class));

    }

    @Override
    protected void onStart() {
        super.onStart();
        Intent startServiceIntent = new Intent(this, EstimoteReceiver.class);
        this.startService(startServiceIntent);

    }


    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.bluetooth.BluetoothAdapter.ACTION_STATE_CHANGED");
        this.registerReceiver(new EstimoteReceiver(), filter);
        SystemRequirementsChecker.checkWithDefaultDialogs(this);
    }
}

