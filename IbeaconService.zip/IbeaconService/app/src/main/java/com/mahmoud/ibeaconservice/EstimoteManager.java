package com.mahmoud.ibeaconservice;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.widget.Toast;

import com.estimote.sdk.Beacon;
import com.estimote.sdk.BeaconManager;
import com.estimote.sdk.Region;
import com.estimote.sdk.BeaconManager.MonitoringListener;
import com.estimote.sdk.Utils;

public class EstimoteManager {
    private static final int NOTIFICATION_ID = 123;
    private static BeaconManager beaconManager;
    private static NotificationManager notificationManager;
    public static final String EXTRAS_BEACON = "extrasBeacon";
    private static final UUID ESTIMOTE_PROXIMITY_UUID = UUID.fromString("f7826da6-4fa2-4e98-8024-bc5b71e0893e");
    // f7826da6-4fa2-4e98-8024-bc5b71e0893e
    private static final Region ALL_ESTIMOTE_BEACONS = new Region("regionId",
            ESTIMOTE_PROXIMITY_UUID, null, null);

    private static Context currentContext;

    // Send SMS

    //get the destance
   public static double getDistance(int rssi, int txPower) {
        return Math.pow(10d, ((double) txPower - rssi) / (10 * 2));
    }
    // Create everything we need to monitor the beacons
    public static void Create(NotificationManager notificationMngr,
                              Context context, final Intent i) {
        try {
            notificationManager = notificationMngr;
            currentContext = context;

            // Create a beacon manager
            beaconManager = new BeaconManager(currentContext);


            // We want the beacons heartbeat to be set at one second.
            beaconManager.setBackgroundScanPeriod(TimeUnit.SECONDS.toMillis(1),
                    0);

            // Method called when a beacon gets...
            beaconManager.setMonitoringListener(new MonitoringListener() {

                // ... close to us.
                @Override
                public void onEnteredRegion(Region region, List<Beacon> beacons) {
                    beaconManager.startRanging(ALL_ESTIMOTE_BEACONS);
                    if(region.getProximityUUID().toString().equals("f7826da6-4fa2-4e98-8024-bc5b71e0893e")){

                        postNotificationIntent("Beacon Found", "I have found my estimote !!!", i);

                    }
                    Toast.makeText(currentContext,region.getProximityUUID().toString(),Toast.LENGTH_SHORT).show();

                }

                // ... far away from us.
                @Override
                public void onExitedRegion(Region region) {

                    Toast.makeText(currentContext,"lest Hello Be4acon",Toast.LENGTH_SHORT).show();

                        //07775dd0-111b-11e4-9191-0800200c9a66
                    if(region.getProximityUUID().toString().equals("f7826da6-4fa2-4e98-8024-bc5b71e0893e")){

                       postNotificationIntent("Beacon lost", "I have lost my estimote !!!", i);

                     }
                    //  postNotificationIntent("Estimote testing",
                    //       "I have lost my estimote !!!", i);
                    //System.out.println("Estimote testing,I have lost my estimote !!!  " + region.getProximityUUID().toString() + i.toString());
                    //sendSMS("03313592298", "i have lost " + region.getProximityUUID().toString());
                }
            });

            // Connect to the beacon manager...
            beaconManager.connect(new BeaconManager.ServiceReadyCallback() {
                @Override
                public void onServiceReady() {
                    try {
                        // ... and start the monitoring
                        beaconManager.startMonitoring(ALL_ESTIMOTE_BEACONS);
                    } catch (Exception e) {
                    }
                }
            });
        } catch (Exception e) {
        }
    }

    // Pops a notification in the task bar
    public static void postNotificationIntent(String title, String msg, Intent i) {
        i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivities(
                currentContext, 0, new Intent[] { i },
                PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(currentContext)
                .setSmallIcon(R.drawable.ic_launcher).setContentTitle(title)
                .setContentText(msg).setAutoCancel(true)
                .setContentIntent(pendingIntent).build();
        notification.defaults |= Notification.DEFAULT_SOUND;
        notification.defaults |= Notification.DEFAULT_LIGHTS;
        notificationManager.notify(NOTIFICATION_ID, notification);
    }

    // Stop beacons monitoring, and closes the service
    public static void stop() {
        try {
            beaconManager.stopMonitoring(ALL_ESTIMOTE_BEACONS);
            beaconManager.disconnect();
        } catch (Exception e) {
        }
    }
}
